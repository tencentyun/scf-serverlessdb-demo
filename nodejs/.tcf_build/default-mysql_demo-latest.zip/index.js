'use strict';

const mysql = require('scf-nodejs-serverlessdb-sdk');

exports.main_handler = async (event, context, callback) => {
    mysql.database().connection((err, conn) => {
        if (!err) {
            conn.query('SELECT * FROM TEST', (err, res) => {
                if (!err) {
                    console.log(res);
                } else {
                    console.error(err);
                }
            });
        } else {
            console.error(err);
        }
    });
};
  